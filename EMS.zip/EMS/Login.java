import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Login extends JDialog implements ActionListener
{
	Welcome wc1;
	ImageIcon ic;
	JLabel l1,l2,l3,lc;
	JTextField t1;
	JPasswordField p1;
	JButton b1,b2,b3;
	Connection conn;
	PreparedStatement ps;
	ResultSet rs;
	Font f1,f2;
	public Login(Welcome wc2)
	{
		wc1=wc2;
		ic=new ImageIcon("loginpage.jpg");
		lc=new JLabel(ic);
		lc.setBounds(0,0,800,800);
		add(lc);
		l1=new JLabel("Username");
		l2=new JLabel("Password");
		l3=new JLabel("LOGIN PAGE");
		t1=new JTextField(40);
		p1=new JPasswordField(40);
		b1=new JButton("Login",new ImageIcon("Login.png"));
		b2=new JButton("Cancel");
		b3=new JButton("New Register");
		f1=new Font("ALGERIAN",Font.BOLD,50);
		f2=new Font("Elephant",Font.BOLD,20);
		l1.setBounds(200,200,150,25);
		lc.add(l1);
		l1.setFont(f2);
		l2.setBounds(200,250,150,25);
		lc.add(l2);
		l2.setFont(f2);
		l3.setBounds(200,10,400,50);
		lc.add(l3);
		l3.setFont(f1);
		t1.setBounds(350,200,110,25);
		lc.add(t1);
		p1.setBounds(350,250,110,25);
		lc.add(p1);
		b1.setBounds(230,320,100,25);
		lc.add(b1);
		b1.setBackground(Color.blue);
		b1.addActionListener(this);
		b2.setBounds(340,320,100,25);
		lc.add(b2);
		b2.setBackground(Color.red);
		b2.addActionListener(this);
		b3.setBounds(280,380,120,25);
		lc.add(b3);
		b3.setBackground(Color.green);
		b3.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(800,800);
		setResizable(false);
		try{
				Class.forName("oracle.jdbc.OracleDriver");
				conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ems","sanny");
			}catch(Exception e1){System.out.println(e1);}
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				String str1 = t1.getText();
				char chkp[] = p1.getPassword();
				String str2 = new String(chkp);
				ps = conn.prepareStatement("select * from account where id=? and pwd=?");
				ps.setString(1,str1);
				ps.setString(2,str2);
				rs = ps.executeQuery();
				if (rs.next())
				{
					setVisible(false);
					EmployeeDetails ed=new EmployeeDetails(this);
					t1.setText("");
					p1.setText("");
				}
				else
				{
					JOptionPane.showMessageDialog(null,"Incorrect Id or password..Try Again with correct detail");
					t1.setText("");
					p1.setText("");
				}
				ps.close();
			}
			if(ae.getSource()==b2)
			{
				setVisible(false);
				wc1.setVisible(true);
			}
			if(ae.getSource()==b3)
			{
				setVisible(false);
				Register rg=new Register(this);
				t1.setText("");
				p1.setText("");
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}
