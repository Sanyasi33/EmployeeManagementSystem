import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class VisitUs extends JDialog implements ActionListener
{
		ImageIcon ic;
	JLabel l1;
	JButton b1;
	EmployeeDetails ed1;
	public VisitUs(EmployeeDetails ed2)
	{
		ed1=ed2;
		ic=new ImageIcon("VisitUs.png");
		l1=new JLabel(ic);
		b1=new JButton("Back",new ImageIcon("back.png"));
		l1.setBounds(0,0,800,800);
		add(l1);
		b1.setBounds(400,650,100,40);
		l1.add(b1);
		setLayout(null);
		setVisible(true);
		setSize(800,800);
		setResizable(false);
		b1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				setVisible(false);
				ed1.setVisible(true);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}