/*Welcome Page*/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Contact extends JDialog implements ActionListener
{
	JLabel l1,l2;
	JButton b1;
	ImageIcon ic;
	Font f;
	EmployeeDetails ed1;
	public Contact(EmployeeDetails ed2)
	{
		ed1=ed2;
		ic=new ImageIcon("contact.png");
		l1=new JLabel(ic);
		b1=new JButton("Back",new ImageIcon("back.png"));
		l1.setBounds(0,0,500,500);
		add(l1);
		b1.setBounds(500,550,200,50);
		add(b1);
		b1.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(800,800);
		setResizable(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				setVisible(false);
				ed1.setVisible(true);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}