import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
public class Viewpage extends JDialog implements ActionListener
{
	Connection conn;
	PreparedStatement ps,sp;
	ResultSet rs;
	ImageIcon ic;
	JLabel lc,l1,l2,l3;
	JTextField t1,t2;
	JButton b1,b2,b3;
	Font tf1,tf2;
	JFrame f1,f2;
	JTable tb1,tb2;
	EmployeeDetails ed1;
	public Viewpage(EmployeeDetails ed2)
	{
		ed1=ed2;
		ic=new ImageIcon("Viewpage.jpg");
		lc=new JLabel(ic);
		lc.setBounds(0,0,800,800);
		add(lc);
		l1=new JLabel("Search Employee");
		l2=new JLabel("Search by Id");
		l3=new JLabel("Search by Dept");
		t1=new JTextField(40);
		t2=new JTextField(40);
		b1=new JButton("Search");
		b2=new JButton("Search");
		b3=new JButton("Cancel");
		tf1=new Font("ALGERIAN",Font.BOLD,40);
		tf2=new Font("Vinque",Font.BOLD,20);
		l1.setBounds(150,1,600,100);
		lc.add(l1);
		l1.setFont(tf1);
		l2.setBounds(80,150,150,25);
		lc.add(l2);
		l2.setFont(tf2);
		l3.setBounds(80,200,150,25);
		lc.add(l3);
		l3.setFont(tf2);
		t1.setBounds(250,150,100,25);
		lc.add(t1);
		t2.setBounds(250,200,100,25);
		lc.add(t2);
		b1.setBounds(380,150,80,25);
		lc.add(b1);
		b1.setBackground(Color.green);
		b1.addActionListener(this);
		b2.setBounds(380,200,80,25);
		lc.add(b2);
		b2.setBackground(Color.green);
		b2.addActionListener(this);
		b3.setBounds(380,250,80,25);
		lc.add(b3);
		b3.setBackground(Color.red);
		b3.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(900,800);
		setResizable(false);
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ems","sanny");
		}
		catch(Exception e1){System.out.println(e1);}
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				String s1=t1.getText();
				int i=0;
				String []fields={"Emp Name","Age","Address","Email","Dept","Emp id","Father's Name","Date of Birth","Phone","Education","Aadhar","PAN Card"};
				f1=new JFrame("Employee Records");
				f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				f1.setLayout(new BorderLayout());
				DefaultTableModel model=new DefaultTableModel();
				model.setColumnIdentifiers(fields);
				tb1 = new JTable();
				tb1.setModel(model);
				tb1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				tb1.setFillsViewportHeight(true);
				JScrollPane scroll=new JScrollPane(tb1);
				scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				sp = conn.prepareStatement("select * from employee where eid=?");
				sp.setString(1,s1);
				rs= sp.executeQuery();
				while(rs.next())
				{
					String st1=rs.getString("ename");
					String st2=rs.getString("age");
					String st3=rs.getString("addr");
					String st4=rs.getString("email");
					String st5=rs.getString("dept");
					String st6=rs.getString("eid");
					String st7=rs.getString("fname");
					String st8=rs.getString("dob");
					String st9=rs.getString("phone");
					String st10=rs.getString("edu");
					String st11=rs.getString("aadh");
					String st12=rs.getString("pan");
					model.addRow(new Object[]{st1,st2,st3,st4,st5,st6,st7,st8,st9,st10,st11,st12});
					i++;
				}
				f1.add(scroll);
				f1.setVisible(true);
				f1.setSize(900,600);
				f1.setResizable(false);
				sp.close();
			}
			if(ae.getSource()==b2)
			{
				String s11=t2.getText();
				int i=0;
				String []fields={"Emp Name","Age","Address","Email","Dept","Emp id","Father's Name","Date of Birth","Phone","Education","Aadhar","PAN Card"};
				f2=new JFrame("Employee Records");
				f2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				f2.setLayout(new BorderLayout());
				DefaultTableModel model=new DefaultTableModel();
				model.setColumnIdentifiers(fields);
				tb2 = new JTable();
				tb2.setModel(model);
				tb2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				tb2.setFillsViewportHeight(true);
				JScrollPane scroll=new JScrollPane(tb2);
				scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				sp = conn.prepareStatement("select * from employee where dept=?");
				sp.setString(1,s11);
				rs= sp.executeQuery();
				while(rs.next())
				{
					String st1=rs.getString("ename");
					String st2=rs.getString("age");
					String st3=rs.getString("addr");
					String st4=rs.getString("email");
					String st5=rs.getString("dept");
					String st6=rs.getString("eid");
					String st7=rs.getString("fname");
					String st8=rs.getString("dob");
					String st9=rs.getString("phone");
					String st10=rs.getString("edu");
					String st11=rs.getString("aadh");
					String st12=rs.getString("pan");
					model.addRow(new Object[]{st1,st2,st3,st4,st5,st6,st7,st8,st9,st10,st11,st12});
					i++;
				}
				f2.add(scroll);
				f2.setVisible(true);
				f2.setSize(900,600);
				f2.setResizable(false);
				sp.close();
			}
			if(ae.getSource()==b3)
			{
				setVisible(false);
				ed1.setVisible(true);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}