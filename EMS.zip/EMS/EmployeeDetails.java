import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class EmployeeDetails extends JDialog implements ActionListener
{
	Login lg1;
	JLabel l1,l2;
	JButton b1,b2,b3,b4,b5,b6,b7;
	Font f;
	ImageIcon ic;
	public EmployeeDetails(Login lg2)
	{
		lg1=lg2;
		ic=new ImageIcon("Employee.jpg");
		l2=new JLabel(ic);
		l2.setBounds(0,0,800,800);
		add(l2);
		l1=new JLabel("Dash Board");
		b1=new JButton("Add");
		b2=new JButton("View");
		b3=new JButton("Remove");
		b4=new JButton("Update");
		b5=new JButton("Back",new ImageIcon("back.png"));
		b6=new JButton("Contact Us");
		b7=new JButton("Visit Us");
		f=new Font("ALGERIAN",Font.BOLD,40);
		l1.setBounds(200,20,500,35);
		l2.add(l1);
		l1.setFont(f);
		b1.setBounds(240,100,100,40);
		l2.add(b1);
		b1.setForeground(Color.blue);
		b1.addActionListener(this);
		b2.setBounds(370,100,100,40);
		l2.add(b2);
		b2.setForeground(Color.green);
		b2.addActionListener(this);
		b3.setBounds(240,160,100,40);
		l2.add(b3);
		b3.setForeground(Color.red);
		b3.addActionListener(this);
		b4.setBounds(370,160,100,40);
		l2.add(b4);
		b4.setForeground(Color.blue);
		b4.addActionListener(this);
		b5.setBounds(300,220,130,30);
		l2.add(b5);
		b5.setBackground(Color.green);
		b5.addActionListener(this);
		b6.setBounds(250,280,100,40);
		l2.add(b6);
		b6.setForeground(Color.green);
		b6.addActionListener(this);
		b7.setBounds(380,280,100,40);
		l2.add(b7);
		b7.setForeground(Color.green);
		b7.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(800,800);
		setResizable(false);
		// setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				setVisible(false);
				AddEmployee ad=new AddEmployee(this);
			}
			if(ae.getSource()==b2)
			{
				setVisible(false);
				Viewpage vw=new Viewpage(this);
			}
			if(ae.getSource()==b3)
			{
				setVisible(false);
				Remove rm=new Remove(this);
			}
			if(ae.getSource()==b4)
			{
				setVisible(false);
				UpdateEmp upd=new UpdateEmp(this);
			}
			if(ae.getSource()==b5)
			{
				setVisible(false);
				lg1.setVisible(true);
			}
			if(ae.getSource()==b6)
			{
				setVisible(false);
				Contact cnt=new Contact(this);
			}
			if(ae.getSource()==b7)
			{
				setVisible(false);
				VisitUs hp=new VisitUs(this);
			}
		}catch (Exception e){System.out.println(e);}
	}
}