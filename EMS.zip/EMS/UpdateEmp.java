import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class UpdateEmp extends JDialog implements ActionListener
{
	EmployeeDetails ed1;
	Connection conn;
	PreparedStatement ps,sp;
	ResultSet rs;
	ImageIcon ic;
	JLabel lc,lt,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
	JButton b1,b2,b3;
	Font f;
	public UpdateEmp(EmployeeDetails ed2)
	{
		ed1=ed2;
		ic=new ImageIcon("Add.jpg");
		lc=new JLabel(ic);
		f=new Font("ALGERIAN",Font.BOLD,40);
		lt=new JLabel("Update Employee Details");
		l1=new JLabel("Name:");
		l2=new JLabel("Age:");
		l3=new JLabel("Address:");
		l4=new JLabel("Email id:");
		l5=new JLabel("Dept. Name:");
		l6=new JLabel("Employee id:");
		l7=new JLabel("Father's Name:");
		l8=new JLabel("Date Of Birth:");
		l9=new JLabel("Phone:");
		l10=new JLabel("Education:");
		l11=new JLabel("Aadhar No:");
		l12=new JLabel("Pan No:");
		t1=new JTextField(40);
		t2=new JTextField(3);
		t3=new JTextField(40);
		t4=new JTextField(40);
		t5=new JTextField(20);
		t6=new JTextField(10);
		t7=new JTextField(40);
		t8=new JTextField(20);
		t9=new JTextField(12);
		t10=new JTextField(40);
		t11=new JTextField(12);
		t12=new JTextField(10);
		b1=new JButton("Update");
		b2=new JButton("Back",new ImageIcon("back.png"));
		lc.setBounds(0,0,800,800);
		add(lc);
		lt.setBounds(120,18,600,40);
		lc.add(lt);
		lt.setForeground(Color.blue);
		lt.setFont(f);
		l1.setBounds(30,170,60,25);
		lc.add(l1);
		l1.setForeground(Color.cyan);
		l2.setBounds(30,210,60,25);
		lc.add(l2);
		l2.setForeground(Color.cyan);
		l3.setBounds(30,250,60,25);
		lc.add(l3);
		l3.setForeground(Color.cyan);
		l4.setBounds(30,290,60,25);
		lc.add(l4);
		l4.setForeground(Color.cyan);
		l5.setBounds(30,330,60,25);
		lc.add(l5);
		l5.setForeground(Color.cyan);
		l6.setBounds(30,370,90,25);
		lc.add(l6);
		l6.setForeground(Color.cyan);
		l7.setBounds(280,170,100,25);
		lc.add(l7);
		l7.setForeground(Color.cyan);
		l8.setBounds(280,210,100,25);
		lc.add(l8);
		l8.setForeground(Color.cyan);
		l9.setBounds(280,250,100,25);
		lc.add(l9);
		l9.setForeground(Color.cyan);
		l10.setBounds(280,290,100,25);
		lc.add(l10);
		l10.setForeground(Color.cyan);
		l11.setBounds(280,330,100,25);
		lc.add(l11);
		l11.setForeground(Color.cyan);
		l12.setBounds(280,370,100,25);
		lc.add(l12);
		l12.setForeground(Color.cyan);
		t1.setBounds(110,170,100,25);
		lc.add(t1);
		t2.setBounds(110,210,100,25);
		lc.add(t2);
		t3.setBounds(110,250,100,25);
		lc.add(t3);
		t4.setBounds(110,290,100,25);
		lc.add(t4);
		t5.setBounds(110,330,100,25);
		lc.add(t5);
		t6.setBounds(110,370,100,25);
		lc.add(t6);
		t7.setBounds(380,170,100,25);
		lc.add(t7);
		t8.setBounds(380,210,100,25);
		lc.add(t8);
		t9.setBounds(380,250,100,25);
		lc.add(t9);
		t10.setBounds(380,290,100,25);
		lc.add(t10);
		t11.setBounds(380,330,100,25);
		lc.add(t11);
		t12.setBounds(380,370,100,25);
		lc.add(t12);
		b1.setBounds(130,450,100,25);
		lc.add(b1);
		b1.addActionListener(this);
		b1.setBackground(Color.blue);
		b2.setBounds(280,450,100,25);
		lc.add(b2);
		b2.addActionListener(this);
		b2.setBackground(Color.green);
		setLayout(null);
		setVisible(true);
		setSize(800,800);
		setResizable(true);
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ems","sanny");
		}
		catch(Exception e1)
		{
			System.out.println(e1);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				String str1 =t6.getText();
				ps = conn.prepareStatement("select eid from employee where eid=?");
				ps.setString(1,str1);
				rs = ps.executeQuery();
				if (rs.next())
				{
					String s1=t1.getText();
					String s2=t2.getText();
					String s3=t3.getText();
					String s4=t4.getText();
					String s5=t5.getText();
					String s6=t6.getText();
					String s7=t7.getText();
					String s8=t8.getText();
					String s9=t9.getText();
					String s10=t10.getText();
					String s11=t11.getText();
					String s12=t12.getText();
					sp=conn.prepareStatement("update employee set ename=?,age=?,addr=?,email=?,dept=?,eid=?,fname=?,dob=?,phone=?,edu=?,aadh=?,pan=? where eid=?");
					sp.setString(1,s1);
					sp.setString(2,s2);
					sp.setString(3,s3);
					sp.setString(4,s4);
					sp.setString(5,s5);
					sp.setString(6,s6);
					sp.setString(7,s7);
					sp.setString(8,s8);
					sp.setString(9,s9);
					sp.setString(10,s10);
					sp.setString(11,s11);
					sp.setString(12,s12);
					sp.setString(13,str1);
					int x=sp.executeUpdate();
					if(x!=-1)
					{
						JOptionPane.showMessageDialog(null,"Details Updated Succesfully...");
						t1.setText("");
						t2.setText("");
						t3.setText("");
						t4.setText("");
						t5.setText("");
						t6.setText("");
						t7.setText("");
						t8.setText("");
						t9.setText("");
						t10.setText("");
						t11.setText("");
						t12.setText("");
					}
					sp.close();
				}
				else
				{
					JOptionPane.showMessageDialog(null,"Employee record not found");
					// t1.setText("");
					// t2.setText("");
					// t3.setText("");
					// t4.setText("");
					// t5.setText("");
					// t6.setText("");
					// t7.setText("");
					// t8.setText("");
					// t9.setText("");
					// t10.setText("");
					// t11.setText("");
					// t12.setText("");
				}
				ps.close();
			}
			if(ae.getSource()==b2)
			{
				conn.close();
				setVisible(false);
				ed1.setVisible(true);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}