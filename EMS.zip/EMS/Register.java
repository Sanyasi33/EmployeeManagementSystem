import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Register extends JDialog implements ActionListener
{
	Connection conn;
	PreparedStatement ps;
	Login lg1;
	JLabel l1,l2,l3,l4,l5;
	JTextField t1;
	JPasswordField p1,p2;
	JButton b1,b2;
	Font f;
	ImageIcon ic;
	public Register(Login lg2)
	{
		lg1=lg2;
		ic=new ImageIcon("Register.jpg");
		l5=new JLabel(ic);
		l5.setBounds(0,0,800,800);
		add(l5);
		l1=new JLabel("User Name:");
		l2=new JLabel("New Password:");
		l3=new JLabel("Confirm Password:");
		l4=new JLabel("Admin Register");
		f=new Font("ALGERIAN",Font.BOLD,45);
		t1=new JTextField(40);
	   	p1=new JPasswordField(10);
		p2=new JPasswordField(10);
		b1=new JButton("Submit");
		b2=new JButton("Back",new ImageIcon("back.png"));
		l1.setBounds(150,160,80,30);
	    l5.add(l1);
		l1.setForeground(new Color(30,144,255));
		l2.setBounds(150,210,90,30);
		l5.add(l2);
		l2.setForeground(new Color(30,144,255));
		l3.setBounds(150,260,110,30);
		l5.add(l3);
		l3.setForeground(new Color(30,144,255));
		l4.setBounds(130,50,500,60);
		l5.add(l4);
		l4.setFont(f);
		l4.setForeground(new Color(127,255,212));
		t1.setBounds(280,160,100,25);
		l5.add(t1);
		p1.setBounds(280,210,100,25);
		l5.add(p1);
		p2.setBounds(280,260,100,25);
		l5.add(p2);
		b1.setBounds(150,320,80,25);
		l5.add(b1);
		b1.setForeground(Color.blue);
		b2.setBounds(250,320,120,25);
		l5.add(b2);
		b2.setForeground(Color.red);
		b1.addActionListener(this);
		b2.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(800,800);
		setResizable(true);
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ems","sanny");
		}
		catch(Exception e1){System.out.println(e1);}
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if (ae.getSource()==b1)
			{
				String s1=t1.getText();
				char ch1[]=p1.getPassword();
				String s2 = new String(ch1);
				char ch2[]=p2.getPassword();
				String s3 = new String(ch2);
				if(s2.compareTo(s3)==0)
				{
					ps=conn.prepareStatement("insert into account(id,pwd,cpwd)values(?,?,?)");
					ps.setString(1,s1);
					ps.setString(2,s2);
					ps.setString(3,s3);
					boolean x=ps.execute();
					if(!x)
					{
						JOptionPane.showMessageDialog(null,"New Admin Registered");
						t1.setText("");
						p1.setText("");
						p2.setText("");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null,"Password Mismatch.....");
					//t1.setText("");
					p1.setText("");
					p2.setText("");
				}
				ps.close();
			}
			if(ae.getSource()==b2)
			{
				conn.close();
				setVisible(false);
				lg1.setVisible(true);
			}
		}
		catch (Exception e)
		{
			System.out.print(e);
		}
	}
}