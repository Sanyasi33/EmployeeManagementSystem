/*Remove page*/
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Remove extends JDialog implements ActionListener
{
	EmployeeDetails ed1;
	ImageIcon ic;
	Connection conn;
	PreparedStatement ps;
	JLabel lc,l1,l2;
	JTextField t1;
	JButton b1,b2;
	Font f1,f2;
	public Remove(EmployeeDetails ed2)
	{
		ed1=ed2;
		ic=new ImageIcon("Remove.jpg");
		lc=new JLabel(ic);
		l1=new JLabel("Delete an Employee");
		l2=new JLabel("Employee Id:");
		t1=new JTextField(40);
		b1=new JButton("Delete",new ImageIcon("Delete.png"));
		b2=new JButton("Back",new ImageIcon("back.png"));
		f1=new Font("ALGERIAN",Font.BOLD,40);
		f2=new Font("Vinque",Font.BOLD,20);
		lc.setBounds(0,0,800,800);
		add(lc);
		l1.setBounds(150,0,600,100);
		lc.add(l1);
		l1.setFont(f1);
		l2.setBounds(330,100,150,25);
		lc.add(l2);
		l2.setFont(f2);
		t1.setBounds(480,100,100,25);
		lc.add(t1);
		b1.setBounds(340,150,110,25);
		lc.add(b1);
		b1.setBackground(Color.red);
		b1.addActionListener(this);
		b2.setBounds(470,150,110,25);
		lc.add(b2);
		b2.setBackground(Color.green);
		b2.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(800,800);
		setResizable(false);
		try
		{
			
			Class.forName("oracle.jdbc.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ems","sanny");
		}
		catch(Exception e1){System.out.println(e1);}
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				String s1 = t1.getText();
				ps = conn.prepareStatement("delete from employee where eid=?");
				ps.setString(1,s1);
				int x=ps.executeUpdate();
				if (x!=0)
				{
					JOptionPane.showMessageDialog(null,"Deletion Successful....");
					t1.setText("");
				}
				else
				{
					JOptionPane.showMessageDialog(null,"No record found");
					t1.setText("");
				}
				ps.close();
			}
			if(ae.getSource()==b2)
			{
				conn.close();
				setVisible(false);
				ed1.setVisible(true);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}