/*Welcome Page*/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Welcome extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JButton b1;
	ImageIcon ic;
	Font f;
	public Welcome()
	{
		ic=new ImageIcon("welcome.jpg");
		l1=new JLabel(ic);
		l2=new JLabel("EMPLOYEE MANAGEMENT SYSTEM");
		b1=new JButton("Click Here to Continue");
		f=new Font("ALGERIAN",Font.BOLD,40);
		l1.setBounds(0,0,1200,1200);
		add(l1);
		l2.setBounds(240,30,800,80);
		l1.add(l2);
		l2.setFont(f);
		l2.setForeground(new Color(135,206,250));
		b1.setBounds(500,550,200,50);
		l1.add(b1);
		b1.setForeground(Color.blue);
		b1.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(1200,1200);
		setResizable(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				setVisible(false);
				Login ln=new Login(this);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String args[])
	{
		Welcome wc=new Welcome();
	}
}